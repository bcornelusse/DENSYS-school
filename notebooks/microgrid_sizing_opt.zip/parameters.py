# This file contains parameters you may want to play with.

import pandas as pd

# Parameters

# SOLVER_CONFIGURATION
EXPORT_MODEL = False

# Time
START_DATE = pd.datetime(2020, 7, 1, 0, 0,
                         0)  # Start date of the sizing run. No error handling if out of the data range.
N_DAYS = 30  # Number of days coinsidered in sizing, from start_date [day]
RESOLUTION_IN_MINUTES = 15  # Time step duration [min]
# Number of operation time steps
N_PERIODS = N_DAYS * 24 * 60 / RESOLUTION_IN_MINUTES
INVESTMENT_HORIZON = 20  # [Years] Investment horizon

# Storage capacity
STORAGE_UNIT_CAPACITY = 90  # [Ah]
STORAGE_UNIT_VOLTAGE = 12  # [V]
STORAGE_UNIT_PRICE = 400  # [EUR]
# [/], means max current is 2 * STORAGE_UNIT_CAPACITY [A]
STORAGE_MAX_C_RATE = 2
INITIAL_SOC = 0  # [Wh]
CHARGE_EFFICIENCY = 0.95  # [/]
DISCHARGE_EFFICIENCY = 0.95  # [/]

# Inverter capacity
INVERTER_UNIT_CAPACITY = 1000  # [VA]
INVERTER_UNIT_PRICE = 300  # [EUR]

# PV
PV_CAPACITY_PRICE = 0.6  # [EUR/Wp]

# Grid connection cost
# Key: [A], value: [EUR/year]
GRID_CAPACITY_PRICE = {16: 5, 32: 12.5, 64: 50}
GRID_VOLTAGE = 230  # [V]
GRID_IMPORT_PRICE = 0.2  # [EUR/kWh]

# Genset
GENSET_CAPACITY_PRICE = {3100: 450, 5500: 750,
                         8000: 2880}  # Key: [VA], value: [EUR]
FUEL_PRICE_COEFF = 0.19  # [EUR/kWh]
