# This file contains utility functions. You mostly do not want to touch this file.

from datetime import timedelta
from pyomo.opt import SolverFactory
from pyomo.opt import ProblemFormat
import pandas as pd
from parameters import *


class SizingData():

    def __init__(self, start_date=pd.datetime(2020, 3, 1, 0, 0, 0)):
        """

        :param start_date: The start date you want to consider for sizing.
        """
        def date_parse(x): return pd.datetime.strptime(
            x, '%Y-%m-%d %H:%M:%S')  # Parsing function

        # Columns are named "C" (consumption) and "P" (production)
        data_df = pd.read_csv("sizing.CSV", index_col="DateTime",
                              parse_dates=True, date_parser=date_parse)

        # Resample data at RESOLUTION_IN_MINUTES
        self.data_df = data_df.resample(
            "%ds" % RESOLUTION_IN_MINUTES*60).mean().interpolate()  # series in W
        self.data_df = self.data_df.loc[start_date:self.data_df.index[-1]]

    def consumption(self, p):
        """

        :param p: period index, starts at 1
        :return: consumption [W]
        """
        datetime = self.data_df.index[0] + \
            timedelta(hours=p * RESOLUTION_IN_MINUTES / 60)
        # DEBUG print(datetime.strftime('%Y-%m-%d %H:%M:%S'))
        return self.data_df.loc[datetime]["load"]

    def PV_generation(self, p):
        """

        :param p: period index, starts at 1
        :return: PV generation per unit of capacity [W]
        """
        datetime = self.data_df.index[0] + \
            timedelta(hours=p * RESOLUTION_IN_MINUTES / 60)
        return self.data_df.loc[datetime]["PV"]


def configure_solver(solver_name="cplex", options={}):
    """
    :param solver_name: solver name as a string
    :param options: dictionnary containing solver specific options
    :return: a configured pyomo solver object
    """
    opt = SolverFactory(solver_name)
    opt.options.update(options)
    return opt


def export_model(model):
    """
    :param model: Pyomo optimization model
    :return: Nothing, dumps lp file sizing_opt.lp
    """
    model.write(filename="sizing_opt.lp",
                format=ProblemFormat.cpxlp,
                io_options={"symbolic_solver_labels": True})
