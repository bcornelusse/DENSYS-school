from pyomo.core.base import Var, Constraint, Objective, NonNegativeReals, Reals, Binary, Integers, maximize
import pyomo.environ as pyo
from pyomo.core.kernel import value
from pyomo.opt import SolverStatus, TerminationCondition
from pyomo.core.base import ConcreteModel, RangeSet, Set
import utils
from parameters import *

# Load data
data = utils.SizingData(START_DATE)

# Create the pyomo model
model = ConcreteModel()

# Create sets
# Time periods of length RESOLUTION_IN_MINUTES
model.periods = RangeSet(N_PERIODS)
model.grid_capacity_options = Set(
    initialize=set(GRID_CAPACITY_PRICE.keys()))  # Index
model.genset_capacity_options = Set(
    initialize=set(GENSET_CAPACITY_PRICE.keys()))  # Index

# Create variables


# Operation variables
model.soc = Var(model.periods, within=NonNegativeReals)  # [Wh]
# Storage charge setpoint [W]
model.charge_storage_sp = Var(model.periods, within=NonNegativeReals)
# Storage discharge setpoint [W]
model.discharge_storage_sp = Var(model.periods, within=NonNegativeReals)
model.gen_PV_sp = Var(model.periods, within=Reals)  # PV generation [W]
model.imp_grid = Var(model.periods, within=NonNegativeReals)  # [W]
model.exp_grid = Var(model.periods, within=NonNegativeReals)  # [W]
model.steer_genset_sp = Var(
    model.periods, within=NonNegativeReals)  # genset setpoint [W]

# Sizing variables
model.storage_energy_capacity_units = Var(within=Integers)
model.storage_inverter_capacity_units = Var(within=Integers)
model.PV_capacity = Var(within=NonNegativeReals)
model.PV_inverter_capacity_units = Var(within=Integers)
model.grid_capacity = Var(model.grid_capacity_options, within=Binary)
model.genset_capacity = Var(model.genset_capacity_options, within=Binary)


# Create constraints

def power_balance_rule(m, p):
    prod_expression = m.imp_grid[p] + m.discharge_storage_sp[p] + \
        m.steer_genset_sp[p] + m.gen_PV_sp[p]
    cons_expression = m.exp_grid[p] + \
        m.charge_storage_sp[p] + data.consumption(p)
    return prod_expression == cons_expression


def storage_level_rule(m, p):
    rhs = 0  # TODO
    return m.soc[p] == rhs


def storage_capacity_rule(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def storage_charge_power_rule1(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def storage_discharge_power_rule1(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def storage_charge_power_rule2(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def storage_discharge_power_rule2(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def PV_generation_rule1(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def PV_generation_rule2(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def import_limit_rule(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def export_limit_rule(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


def grid_connection_choice_rule(m):
    constraint = (0 == 0)  # TODO
    return constraint


def genset_generation_rule(m, p):
    constraint = (0 == 0)  # TODO
    return constraint


model.power_balance_cstr = Constraint(model.periods, rule=power_balance_rule)

model.storage_level_cstr = Constraint(model.periods, rule=storage_level_rule)
model.storage_capacity_cstr = Constraint(
    model.periods, rule=storage_capacity_rule)
model.storage_charge_power_cstr1 = Constraint(
    model.periods, rule=storage_charge_power_rule1)
model.storage_discharge_power_cstr1 = Constraint(
    model.periods, rule=storage_discharge_power_rule1)
model.storage_charge_power_cstr2 = Constraint(
    model.periods, rule=storage_charge_power_rule2)
model.storage_discharge_power_cstr2 = Constraint(
    model.periods, rule=storage_discharge_power_rule2)

model.PV_generation_cstr1 = Constraint(model.periods, rule=PV_generation_rule1)
model.PV_generation_cstr2 = Constraint(model.periods, rule=PV_generation_rule2)

model.import_limit_cstr = Constraint(model.periods, rule=import_limit_rule)
model.export_limit_cstr = Constraint(model.periods, rule=export_limit_rule)
model.grid_connection_choice_cstr = Constraint(
    model.periods, rule=grid_connection_choice_rule)

model.genset_generation_cstr = Constraint(
    model.periods, rule=genset_generation_rule)


# Create objective

def total_cost(m):
    """Pay attention to the time resolution and units!"""
    opex = 0  # TODO
    capex = 0  # TODO

    return capex + opex


model.NPV = Objective(rule=total_cost, sense=pyo.minimize)

# Solve the model
opt = utils.configure_solver(solver_name="cplex")
if EXPORT_MODEL:
    print("Exporting model...")
    utils.export_model(model)
print("Solving model...")
results = opt.solve(model, tee=True, keepfiles=False)

# Check is the problem is feasible
status = results.solver.status
termination_condition = results.solver.termination_condition
print()
print("Solver status:", status, termination_condition)

# Analyze the results
print("Storage capacity [Wh]: %d" % (
    model.storage_energy_capacity_units.value * STORAGE_UNIT_CAPACITY * STORAGE_UNIT_VOLTAGE))
print("Storage inverter capacity [VA]: %d" % (
    model.storage_inverter_capacity_units.value * INVERTER_UNIT_CAPACITY))
print("PV capacity [Wp]: %d" % (model.PV_capacity.value))
print("PV inverter capacity [VA]: %d" % (
    model.PV_inverter_capacity_units.value * INVERTER_UNIT_CAPACITY))
print("Grid connection capacity [A]: %d" % (
    sum(o * model.grid_capacity[o].value for o in model.grid_capacity_options)))
print("Genset capacity [VA]: %d" % (
    sum(o * model.genset_capacity[o].value for o in model.genset_capacity_options)))
