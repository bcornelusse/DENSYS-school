from pyomo.environ import *
import pandas as pd
import numpy as np
from param import total_hours, time_steps, delta_t

from param import delta_t, time_steps, total_hours
#from param import P_nom_pv, P_max_gen, P_min_gen, C_bss, SOC_min_bss, SOC_max_bss, eff_bss, P_nom_bss
from param import C_ev, eff_ev, C_bss, eff_bss
import utils

import matplotlib.pyplot as plt


def compute_remaining_time(EV_connected):  # This function computes the remaining time for the current EV connection
    # Find the next time step where EV is disconnected and return its index
    remaining_time = next((i for i, value in enumerate(EV_connected) if value == 0), len(EV_connected)) 
    return remaining_time * delta_t

class Results:
    def __init__(self,Scenario):
        self.P_pv = np.zeros(time_steps)
        self.P_bss = np.zeros(time_steps)
        self.P_ev = np.zeros(time_steps)
        self.P_gen = np.zeros(time_steps)

        self.SOC_ev = np.zeros(time_steps)
        self.SOC_bss = np.zeros(time_steps)

        # Load data from CSV files into pandas DataFramess
        Load_data = pd.read_csv('Load.csv', delimiter=';', index_col=0)
        PV_data = pd.read_csv('PV.csv', delimiter=';', index_col=0)
        EV_data = pd.read_csv('EV.csv', delimiter=';', index_col=0)

        self.P_pv_max = np.array(PV_data[Scenario])/100         # Scale PV production in kW
        self.P_load = np.array(Load_data[Scenario])/1000        # Scale demand curve in kW
        self.EV_connected  = np.array(EV_data[Scenario])        # EV connection status


        # Initialize SOCs
        if   Scenario == 'S1': self.SOC_ev[0] = 0.6*C_ev ; self.SOC_bss[0] = 0.5*C_bss 
        elif Scenario == 'S2': self.SOC_ev[0] = 0.7*C_ev ; self.SOC_bss[0] = 0.5*C_bss
        elif Scenario == 'S3': self.SOC_ev[0] = 0.3*C_ev ; self.SOC_bss[0] = 0.5*C_bss 
        elif Scenario == 'S4': self.SOC_ev[0] = 0.3*C_ev ; self.SOC_bss[0] = 0.5*C_bss          

        self.t = np.linspace(0, total_hours, time_steps)  

    def append_res(self, P_pv, P_gen, P_bss, P_ev, t):
        self.P_pv[t] = P_pv
        self.P_bss[t] = P_bss
        self.P_ev[t] = P_ev
        self.P_gen[t] = P_gen
        self.state_update(P_ev,P_bss,t)

    def state_update(self, P_ev, P_bss, t):
        if t == 0: return KeyError
        self.SOC_ev[t] = self.SOC_ev[t-1] + delta_t * max(P_ev,0)*eff_ev  + delta_t * min(P_ev,0) / eff_ev
        self.SOC_bss[t] = self.SOC_bss[t-1] + delta_t * max(P_bss,0)*eff_bss + delta_t * min(P_bss,0) / eff_bss

def run_sim(control_function, Scenario, model=None, FORECAST=False, verbose=False):      
    # Initialize arrays to store time-series results for various parameters
    results = Results(Scenario)
        
    for t in np.arange(1, time_steps):
        # Compute the remaining time for EV connection at each time step
        EV_remaining_time = compute_remaining_time(results.EV_connected[t:]) if results.EV_connected[t] else 0

        # Call the control function to determine the power outputs
        P_pv, P_gen, P_bss, P_ev = control_function(results.P_load[t], results.P_pv_max[t], results.EV_connected[t],
                                                    EV_remaining_time, results.P_gen[t-1], 
                                                    results.SOC_bss[t-1]/C_bss, results.SOC_ev[t-1]/C_ev, model)
        
        # Append results to the results object and update SOCs
        results.append_res(P_pv, P_gen, P_bss, P_ev, t)
        if verbose:
            print("Time index ", t)
            print(results.SOC_ev[t],results.SOC_bss[t],results.P_load[t],results.P_pv_max[t])
        
    print("Simulation completed")
    utils.plot(results)
    utils.print(results)