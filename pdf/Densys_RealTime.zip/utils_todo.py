import matplotlib.pyplot as plt
import numpy as np
from param import *

def check(res):
    # TODO: check that all your results are within physical limits
    # Print something if there is an error
    # Do it in a way to help you debug
    return

def print(res):
    # TODO: print informations on the overall simulation results
    # This should not spam the console
    return

def plot(res):
    # TODO: plot the powers and other results for the simulation 
    # You can access data like this
    # Load = res.P_load
    # P_pv_max = res.P_pv_max
    # etc.
    return

