from param import delta_t, time_steps, total_hours
from param import P_nom_pv, P_max_gen, P_min_gen, C_bss, SOC_min_bss, SOC_max_bss, eff_bss, P_nom_bss
from param import C_ev, eff_ev, SOC_min_ev, SOC_max_ev, P_nom_ev, SOC_target_ev

from pyomo.environ import ConcreteModel, Param, Var, Objective, Constraint, value, NonNegativeReals, Binary, minimize, SolverFactory, SolverStatus
import time
import run

OPTIMIZATION = True
Scenario = "S1" # Change to S2, S3, S4 to test the different scenarios

# =============================================================================
# Additional parameters
# =============================================================================
PI_gen = 0.4
# You can add some parameters here

def create_model():
    # Create a concrete model
    model = ConcreteModel()
    
    # Mutable parameters that will be updated at each time step
    model.SOC_ev = Param(mutable=True)                      # Replace with your current electric vehicle state of charge [0, 1]
    model.SOC_bss = Param(mutable=True)                     # Replace with your current battery state of charge [0, 1]
    model.P_load = Param(mutable=True)                      # Replace with your current estimate of the load 
    model.P_pv_max = Param(mutable=True)                    # Replace with your current estimate of the max available PV power
    model.EV_connected = Param(mutable=True, within=Binary) # Depends on wether the electric vehicle is connected or not
    model.EV_time_remaining = Param(mutable=True)           # Time remaining before the EV is leaving
    model.Pgen_prev = Param(mutable=True, initialize=0)    # Power output of the generator at the previous time step

    # Variables
    model.P_pv = Var(within=NonNegativeReals)               # PV power output 
    model.P_gen = Var(within=NonNegativeReals)              # Generator power output 
    model.P_charge_bss = Var(within=NonNegativeReals)       # Battery charging power 
    model.P_discharge_bss = Var(within=NonNegativeReals)    # Battery discharging power 
    model.P_charge_ev = Var(within=NonNegativeReals)        # EV charging power 
    model.P_discharge_ev = Var(within=NonNegativeReals)     # EV discharging power 
    # Binary variables for mode control
    model.gen_status = Var(within=Binary, initialize=0)     # Indicates whether generator is on 
        
    # Define the objective function ----------------------------------------------------------------------------
    model.objective = Objective(sense=minimize,
    expr=0) #TODO
    
    #Constraints ---------------------------------------------------------------------------------------------------------------------------
    # Power balance constraint:
    model.P_bal_cstr = Constraint(expr= model.P_load==model.P_pv) #TODO: Complete
    
    # PV constraints:#TODO
    
    # Battery constraints: #TODO

    # EV constraints: #TODO

    # Generator power constraints: #TODO
    
    return model

def solve_model(model): # You shouldn't change this function except for debugging/printing
    # Solve the optimization problem
    solver = SolverFactory('gurobi')
    results = solver.solve(model)#, tee=True)  # Parameter 'tee=True' prints the solver output
    
    status = results.solver.status

    # Check the solution status
    if status == SolverStatus.ok:
        pass
    elif status == SolverStatus.warning:
        print("Solver finished with a warning.")
    elif status == SolverStatus.error:
        print("Solver encountered an error and did not converge.")
    elif status == SolverStatus.aborted:
        print("Solver was aborted before completing the optimization.")
    else:
        print("Solver status unknown.")

def update_model(model, SOC_bss, SOC_ev, P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev): 
    # You can change this function if you add mutable parameters in the model and you want to update them
    model.SOC_ev = SOC_ev
    model.SOC_bss = SOC_bss
    model.P_load = P_load
    model.P_pv_max = P_pv_max
    model.EV_connected = EV_connected
    model.EV_time_remaining = EV_remaining_time
    model.Pgen_prev = P_gen_prev
    return model


#===============================================================================================================#
    # Control decision function
    # This function is used to determine the power setpoints for the different components of the system
    # It is called at each time step to determine the power setpoints for the next time step
    # The function should return the following values:
    # P_pv: Power output of the PV system
    # P_gen: Power output of the generator
    # P_bss: Power output of the battery
    # P_ev Power output of the EV
    # These values are used to update the state of the system and to calculate the cost of the system operation

    # The function takes the following inputs:
    # t: Current time step
    # P_load: Demand at the current time step
    # P_pv_max: Maximum available power from the PV system
    # EV_connected: Maximum power that can be drawn from the EV
    # EV_remaining_time: Time remaining before the EV leaves
    # P_gen_prev: Power output of the generator at the previous time step
    # SOC_bss: Current battery state of charge [0, 1]
    # SOC_EV: Current EV state of charge [0, 1]
    # model: pyomo object of your optimization model
#===============================================================================================================#


def control_decision(P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev, SOC_bss, SOC_ev, model): 
    # You should not change the input and outputs of this function
    model = update_model(model, SOC_bss, SOC_ev, P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev)

    solve_model(model)

    P_pv = model.P_pv.value
    P_gen = model.P_gen.value
    P_bss = model.P_charge_bss.value - model.P_discharge_bss.value
    P_ev = model.P_charge_ev.value - model.P_discharge_ev.value
    return P_pv, P_gen, P_bss, P_ev

model = create_model()
run.run_sim(control_decision, Scenario, model, FORECAST=False)


