from param import delta_t, time_steps, total_hours
from param import P_nom_pv, P_max_gen, P_min_gen, C_bss, SOC_min_bss, SOC_max_bss, eff_bss, P_nom_bss
from param import C_ev, eff_ev, SOC_min_ev, SOC_max_ev, P_nom_ev, SOC_target_ev

import run, utils


MODEL_BASED = False
Scenario = 'S1' # Change to S2, S3, S4 to test the different scenarios

#===============================================================================================================#
    # Control decision function
    # This function is used to determine the power setpoints for the different components of the system
    # It is called at each time step to determine the power setpoints for the next time step
    # The function should return the following values:
    # P_pv: Power output of the PV system
    # P_gen: Power output of the generator
    # P_bss: Power output of the battery
    # P_ev Power output of the EV
    # These values are used to update the state of the system and to calculate the cost of the system operation

    # The function takes the following inputs:
    # t: Current time step
    # P_load: Demand at the current time step
    # P_pv_max: Maximum available power from the PV system
    # EV_connected: Maximum power that can be drawn from the EV
    # EV_remaining_time: Time remaining before the EV leaves
    # P_gen_prev: Power output of the generator at the previous time step
    # SOC_bss: Current battery state of charge [0, 1]
    # SOC_EV: Current EV state of charge [0, 1]
#===============================================================================================================#

def control_decision(P_load, P_pv_max, EV_connected, 
                     EV_remaining_time, P_gen_prev, SOC_bss, SOC_ev):
    # Define the ouput, you should write your controller here
    P_pv = 0
    P_gen = 0
    P_bss = 0  
    P_ev = 0
    return P_pv, P_gen, P_bss, P_ev

run.run_sim(control_decision, Scenario, MODEL_BASED, FORECAST=False)




