import matplotlib.pyplot as plt
from pyomo.environ import SolverFactory, SolverStatus
from datetime import timedelta
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from param import *
from plotly.subplots import make_subplots

def check_res(res):
    return

def print_res(res):
    return

def plot_res(res):
    return

def print_sizing_results(res):
    return

def solve_model(m, res):
    # Solve the optimization problem
    solver = SolverFactory('gurobi')
    output = solver.solve(m)#, tee=True)  # Parameter 'tee=True' prints the solver output

    # Print elapsed time
    status = output.solver.status

    # Check the solution status
    if status == SolverStatus.ok:
        print("Simulation completed")
        res = save_results(res, m)
        res.save_sizing_results(m)
        return m, res
    elif status == SolverStatus.warning:
        print("Solver finished with a warning.")
    elif status == SolverStatus.error:
        print("Solver encountered an error and did not converge.")
    elif status == SolverStatus.aborted:
        print("Solver was aborted before completing the optimization.")
    else:
        print("Solver status unknown.")
    return None, None

class Results:
    def __init__(self, start_time, n_days, yearly_kwh, yearly_km):
        self.start_time = start_time 
        self.t_s = int(n_days*24/delta_t)                # Total number of discrete time steps in the simulation
        self.n_days = n_days
        self.yearly_kwh = yearly_kwh
        self.yearly_km = yearly_km
        self.t = np.arange(0,self.t_s)

        self.P_pv = np.zeros(self.t_s)
        self.P_bss = np.zeros(self.t_s)
        self.P_ev = np.zeros(self.t_s)
        self.P_gen = np.zeros(self.t_s)
        self.P_imp = np.zeros(self.t_s)
        self.P_exp = np.zeros(self.t_s)

        self.SOC_ev = np.zeros(self.t_s)
        self.SOC_bss = np.zeros(self.t_s)

        # Initialize SOCs
        self.SOC_bss_i = 0.5          

        # Load data from CSV files into pandas DataFrames
        self.df = pd.read_csv('HW2.csv', delimiter=';', index_col="DateTime", parse_dates=True, date_format='%Y-%m-%d %H:%M:%S')#, date_parser=lambda x: datetime.strptime(x, '%Y-%m-%d %H:%M:%S'))
        self.P_load = np.array([self.df.loc[self.start_time + timedelta(hours=t*delta_t)]["Load"].clip(min=0) * self.yearly_kwh for t in self.t])
        self.P_pv_max = np.array([self.df.loc[self.start_time + timedelta(hours=t*delta_t)]["PV"].clip(min=0) for t in self.t])
        self.EV_connected = np.array([self.df.loc[self.start_time + timedelta(hours=t*delta_t)]["EV"] for t in self.t])
        self.datetime = [self.start_time + timedelta(hours=t*delta_t) for t in self.t]


        self.SOC_ev_i = [SOC_target_ev*C_ev - (self.EV_connected[t]*self.yearly_km) / (5e6) for t in range(self.t_s) if self.EV_connected[t] > 0 and (t == 0 or self.EV_connected[t-1] == 0)]
        self.t_arr = [t for t in range(self.t_s) if self.EV_connected[t] > 0 and (t == 0 or self.EV_connected[t-1] == 0)]
        self.t_dep = [t for t in range(self.t_s) if self.EV_connected[t] == 0 and (t > 0 and self.EV_connected[t-1] > 0)] + ([self.t_s-1] if self.EV_connected[-1] > 0 else [])
        self.EV_connected = [1 if self.EV_connected[t] > 0 else 0 for t in range(self.t_s)]

    def save_sizing_results(self, m):
        self.C_bss = m.C_bss.value
        self.P_nom_bss = m.P_nom_bss.value
        self.C_pv = m.C_pv.value
        self.P_nom_pv = m.P_nom_pv.value
        self.C_ev = m.C_ev.value
        self.P_nom_ev = m.P_nom_ev.value
        self.P_max_gen = m.P_max_gen.value

def save_results(res, m):
    res.P_imp = np.array([m.P_imp[t].value for t in m.periods])
    res.P_exp = np.array([m.P_exp[t].value for t in m.periods])
    res.P_pv = np.array([m.P_pv[t].value for t in m.periods])
    res.P_bss = np.array([m.P_charge_bss[t].value - m.P_discharge_bss[t].value for t in m.periods])
    res.P_ev = np.array([m.P_charge_ev[t].value - m.P_discharge_ev[t].value for t in m.periods])
    res.P_gen = np.array([m.P_gen[t].value for t in m.periods])
    res.SOC_ev = np.array([m.SOC_ev[t].value for t in m.periods])
    res.SOC_bss = np.array([m.SOC_bss[t].value for t in m.periods])
    res.objective = m.objective()
    return res


def plot_res2(res, vert_lines=True):
    # Create an interactive plotly figure
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.1,
        subplot_titles=("Power Values Over Time", "State of Charge Over Time"),
        specs=[[{"type": "scatter"}], [{"type": "scatter"}]]
    )
    # Reconstruct P_charge and P_discharge
    P_dis_bss = -np.minimum(0, res.P_bss)
    P_ch_bss = -np.maximum(0, res.P_bss)
    P_dis_ev = -np.minimum(0, res.P_ev)
    P_ch_ev = -np.maximum(0, res.P_ev)

    # Add traces for positive power values (generation)
    fig.add_trace(go.Scatter(x=res.datetime, y=res.P_imp, mode='lines', name='Imports', stackgroup='positive'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=res.P_pv, mode='lines', name='PV', stackgroup='positive'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=res.P_gen, mode='lines', name='Generator', stackgroup='positive'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=P_dis_bss, mode='lines', name='BSS (Discharge)', stackgroup='positive'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=P_dis_ev, mode='lines', name='EV (Discharge)', stackgroup='positive'), row=1, col=1)

    # Add traces for negative power values (consumption)
    fig.add_trace(go.Scatter(x=res.datetime, y=-res.P_load, mode='lines', name='Load', stackgroup='negative'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=P_ch_bss, mode='lines', name='BSS (Charge)', stackgroup='negative'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=P_ch_ev, mode='lines', name='EV (Charge)', stackgroup='negative'), row=1, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=-res.P_exp, mode='lines', name='Exports', stackgroup='negative'), row=1, col=1)

    # Second subplot for SOC values
    fig.add_trace(go.Scatter(x=res.datetime, y=res.SOC_ev / res.C_ev * 100, mode='lines', name='EV SOC [%]'), row=2, col=1)
    fig.add_trace(go.Scatter(x=res.datetime, y=res.SOC_bss / res.C_bss * 100, mode='lines', name='Battery SOC [%]'), row=2, col=1)

    if vert_lines: # Add vertical lines for EV arrival and departure times
        for t in res.t_arr:
            fig.add_vline(x=res.datetime[t], line=dict(color="green", width=1, dash="dash"), row=2, col=1)
        for t in res.t_dep:
            fig.add_vline(x=res.datetime[t], line=dict(color="red", width=1, dash="dash"), row=2, col=1)

    # Update layout for the figure
    fig.update_layout(
        title="Simulation Results",
        xaxis_title="Time",
        yaxis_title="Power [kW]",
        yaxis2_title="State of Charge [%]",
        legend_title="Legend",
        template="plotly_white",
        hovermode="x unified"
    )

    # Show the interactive plot
    fig.show()
    return
