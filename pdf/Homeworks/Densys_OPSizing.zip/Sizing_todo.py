from param import delta_t, inv_hor, C_pv_max, C_bss_max
from param import SOC_i_bss, SOC_min_bss, SOC_max_bss, eff_bss
from param import C_ev, P_nom_ev, eff_ev, SOC_min_ev, SOC_max_ev, SOC_target_ev
from param import PI_gen, PI_imp, PI_exp, PI_c_inv, PI_c_bss, PI_c_pv, PI_c_gen
from pyomo.environ import ConcreteModel, Param, Var, Objective, Constraint, NonNegativeReals, minimize
from datetime import datetime
import utils
import numpy as np

def create_model(res):
    # Create a concrete model
    model = ConcreteModel()
    
    model.periods = range(res.t_s)                          # A set is created with length equal to the number of time steps in the simulation
    model.connections = range(len(res.t_arr))               # A set is created with length equal to the number of EV connections

    # Access all parameters present in the res object.
    # These exists for each t in model.t:
    #  - res.P_load[t] = Load power at time t
    #  - res.P_pv_max[t] = Max available PV power at time t
    #  - res.EV_connected[t] = EV connected at time t

    # These exists for each c in model.connections:
    #  - res.t_arr[c] = Time at which the EV is connected for the c-th connection
    #  - res.t_dep[c] = Time at which the EV is disconnected for the c-th connection
    #  - res.SOC_i_ev[c] = Initial SOC of the EV connected at time t_arr[c]
    
    # Asset sizes
    model.P_nom_pv = Var(within=NonNegativeReals)                           # Nominal power for PV inverter
    model.C_bss = Var(within=[0,C_bss_max])                                 # Battery capacity
    model.C_pv = Var(within=[0,C_pv_max])                                   # PV system size
    model.P_nom_bss = Var(within=NonNegativeReals)                          # Battery inverter nominal power
    model.P_max_gen = Var(within=NonNegativeReals)                          # Maximum generator power
    model.P_nom_ev = Param(initialize=P_nom_ev)                             # EV charger nominal power
    model.C_ev = Param(initialize=C_ev)                                     # EV capacity

    # Variables
    model.P_imp = Var(model.periods, within=NonNegativeReals)               # Imported power
    model.P_exp = Var(model.periods, within=NonNegativeReals)               # Exported power 
    model.P_pv = Var(model.periods, within=NonNegativeReals)                # PV power output 
    model.P_gen = Var(model.periods, within=NonNegativeReals)               # Generator power output 
    model.P_charge_bss = Var(model.periods, within=NonNegativeReals)        # Battery charging power 
    model.P_discharge_bss = Var(model.periods, within=NonNegativeReals)     # Battery discharging power 
    model.P_charge_ev = Var(model.periods, within=NonNegativeReals)         # EV charging power 
    model.P_discharge_ev = Var(model.periods, within=NonNegativeReals)      # EV discharging power 

    # Energy storage variables for battery and EV
    model.SOC_bss = Var(model.periods, within=NonNegativeReals)             # Bss state of charge [kWh]
    model.SOC_ev = Var(model.periods, within=NonNegativeReals)              # EV state of charge [kWh]
    
    # Define the objective function ----------------------------------------------------------------------------
    model.objective = Objective(sense = minimize,
                                expr = 0)
    
    #Constraints ---------------------------------------------------------------------------------------------------------------------------
    # Power balance constraint:

    # Battery Energy constraints

    # PV power constraint:

    # Battery charging and discharging constraints:

    # EV charging and discharging constraints:

    # EV target SOC constraint:

    # Generator power constraints:
    

    return model

def run(model, results):
    model, results = utils.solve_model(model, results)
    if model and results:
        utils.print_sizing_results(results)
        utils.check_res(results)
        utils.print_res(results)
        utils.plot_res2(results) # /!\ Do not use this plotting function to create plots for your report. It is only for interactive visualisation purposes.
    return results

start_time = datetime(2021, 1, 1, 0, 0, 0)                                  # Start time of the simulation [YYYY, MM, DD, HH, MM, SS]
n_days = 30                                                                 # Number of days to simulate
results = utils.Results(start_time, n_days, yearly_kwh=0, yearly_km=0)      # Initialize results object with start time and number of days, yearly consumption and km driven
model = create_model(results)
run(model, results)