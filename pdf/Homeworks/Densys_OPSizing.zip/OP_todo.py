from param import delta_t
from param import SOC_i_bss, SOC_min_bss, SOC_max_bss, eff_bss
from param import C_ev, P_nom_ev, eff_ev, SOC_min_ev, SOC_max_ev, SOC_target_ev
from param import PI_gen, PI_imp, PI_exp
from pyomo.environ import ConcreteModel, Param, Var, Objective, Constraint, NonNegativeReals, minimize
from datetime import datetime
import utils

C_pv = 10                            # PV system size [kWp]
C_bss = 40                           # Battery capacity [kWh]	
P_nom_bss = 10                       # Battery inverter nominal power [kW]
P_nom_pv = 10                        # PV inverter nominal power [kW]
P_max_gen = 10                       # Maximum generator power [kW]

    # Access all parameters present in the res object.
    # These exists for each t in model.t:
    #  - res.P_load[t] = Load power at time t
    #  - res.P_pv_max[t] = Max available PV power at time t [kW/kWp]
    #  - res.EV_connected[t] = EV connected at time t

    # These exists for each c in model.connections:
    #  - res.t_arr[c] = Time at which the EV is connected for the c-th connection
    #  - res.t_dep[c] = Time at which the EV is disconnected for the c-th connection
    #  - res.SOC_i_ev[c] = Initial SOC of the EV connected at time t_arr[c]
    

def create_model(res):
    # Create a concrete model
    model = ConcreteModel()
    
    model.periods = range(res.t_s)
    model.connections = range(len(res.t_arr)) # A set is created with length equal to the number of EV connections

    # Operation planning asset sizes
    model.P_nom_pv = Param(initialize=P_nom_pv)                            # Nominal power for PV inverter [kW]
    model.C_bss = Param(initialize=C_bss)                                  # Battery capacity [kWh]
    model.C_pv = Param(initialize=C_pv)                                    # PV system size [kWp]
    model.P_nom_bss = Param(initialize=P_nom_bss)                          # Battery inverter nominal power [kW]
    model.P_nom_ev = Param(initialize=P_nom_ev)                            # EV charger nominal power [kW]
    model.C_ev = Param(initialize=C_ev)                                    # EV capacity [kWh]
    model.P_max_gen = Param(initialize=P_max_gen)                          # Maximum generator power [kW]

    # Variables
    model.P_imp = Var(model.periods, within=NonNegativeReals)              # Imported power [kW]
    model.P_exp = Var(model.periods, within=NonNegativeReals)              # Exported power [kW]
    model.P_pv = Var(model.periods, within=NonNegativeReals)               # PV power output  [kW]
    model.P_gen = Var(model.periods, within=NonNegativeReals)              # Generator power output [kW]
    model.P_charge_bss = Var(model.periods, within=NonNegativeReals)       # Battery charging power [kW]
    model.P_discharge_bss = Var(model.periods, within=NonNegativeReals)    # Battery discharging power [kW]
    model.P_charge_ev = Var(model.periods, within=NonNegativeReals)        # EV charging power [kW]
    model.P_discharge_ev = Var(model.periods, within=NonNegativeReals)     # EV discharging power [kW] 

    model.SOC_bss = Var(model.periods, within=NonNegativeReals)            # Bss state of charge [kWh]
    model.SOC_ev = Var(model.periods, within=NonNegativeReals)             # EV state of charge [kWh]
    
    # Define the objective function ----------------------------------------------------------------------------
    model.objective = Objective(sense=minimize, expr=0)
    
    #Constraints ---------------------------------------------------------------------------------------------------------------------------
    # Power balance constraint:
    model.P_bal_cstr = Constraint(model.periods, expr=lambda model,t: res.P_load[t]==model.P_gen[t]) # This will be ensured for all time steps t. You should access variables etc with model.variable_name[t]

    # Battery Energy constraints:

    # PV power constraints:

    # Battery charging and discharging power constraints:

    # EV charging and discharging power constraints:

    # EV target SOC constraint:
    # This will be ensured for all connections c. You should access variables etc with model.variable_name[t_dep[c]]
    model.EV_target_cstr = Constraint(model.connections, expr=lambda model, c: 0 == 0) 

    # Generator power constraints:

    return model

def run(model, results):
    model, results = utils.solve_model(model, results)
    if model and results:
        utils.check_res(results)
        utils.print_res(results)
        utils.plot_res2(results) # /!\ Do not use this plotting function to create plots for your report. It is only for interactive visualisation purposes.
    return results

start_time = datetime(2021, 1, 1, 0, 0, 0)                                  # Start time of the simulation [YYYY, MM, DD, HH, MM, SS]
n_days = 30                                                                 # Number of days to simulate
results = utils.Results(start_time, n_days, yearly_kwh=0, yearly_km=0)      # Initialize results object with start time and number of days, yearly consumption and km driven
model = create_model(results)
run(model, results)
