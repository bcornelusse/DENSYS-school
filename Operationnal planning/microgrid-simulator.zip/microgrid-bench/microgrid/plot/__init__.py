"""
The plot package gathers all plotting functions.
"""

from plot_results import Plotter

__all__ = [
    'Plotter'
]