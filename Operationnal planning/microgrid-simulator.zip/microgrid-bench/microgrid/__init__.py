"""
The microgrid package organizes the test-bench functionalities in subpackages.
"""