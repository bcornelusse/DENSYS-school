from pyomo.core.base import Var, Constraint, Objective, NonNegativeReals, Reals, Binary, Integers, maximize, Param
import pyomo.environ as pyo
from pyomo.core.kernel import value
from pyomo.opt import SolverStatus, TerminationCondition
from pyomo.core.base import ConcreteModel, RangeSet, Set
import utils
from parameters import *

import Plot

# Load data
data = utils.SizingData(START_DATE)

# Create the pyomo model
model = ConcreteModel()

# Create sets
# Time periods of length RESOLUTION_IN_MINUTES
model.periods = RangeSet(N_PERIODS)

# Create variables

# Operation variables
model.soc = Var(model.periods, within=NonNegativeReals)  # [Wh]
# Storage charge setpoint [W]
model.charge_storage_sp = Var(model.periods, within=NonNegativeReals)
# Storage discharge setpoint [W]
model.discharge_storage_sp = Var(model.periods, within=NonNegativeReals)
model.gen_PV_sp = Var(model.periods, within=NonNegativeReals)  # PV generation [W]
model.imp_grid = Var(model.periods, within=NonNegativeReals)  # [W]
model.exp_grid = Var(model.periods, within=NonNegativeReals)  # [W]
model.steer_genset_sp = Var(
    model.periods, within=NonNegativeReals)  # genset setpoint [W]

# Sizing Parameters #TODO: add default value depending on your case study
model.storage_energy_capacity = Param(default=0)
model.storage_inverter_capacity = Param(default=0)
model.PV_capacity = Param(default=0)
model.PV_inverter_capacity = Param(default=0)
model.grid_capacity = Param(default=0)
model.genset_capacity = Param(default=0)

# Create constraints

def power_balance_rule(m, p):
    prod_expression = 0
    cons_expression = 0
    return prod_expression >= cons_expression


def storage_level_rule(m, p):
    return 0 == 0


def storage_capacity_rule(m, p):
    return 0 == 0


def storage_charge_power_rule1(m, p):
    return 0 == 0


def storage_discharge_power_rule1(m, p):
    return 0 == 0


def storage_charge_power_rule2(m, p):
    return 0 == 0


def storage_discharge_power_rule2(m, p):
    return 0 == 0


def PV_generation_rule1(m, p):
    return 0 == 0


def PV_generation_rule2(m, p):
    return 0 == 0

def import_limit_rule(m, p):
    return 0 == 0


def export_limit_rule(m, p):
    return 0 == 0

def genset_generation_rule(m, p):
    return 0 == 0


model.power_balance_cstr = Constraint(model.periods, rule=power_balance_rule)

model.storage_level_cstr = Constraint(model.periods, rule=storage_level_rule)
#model.end_state_of_charge_cstr = Constraint(rule=end_state_of_charge_rule)
model.storage_capacity_cstr = Constraint(
    model.periods, rule=storage_capacity_rule)
model.storage_charge_power_cstr1 = Constraint(
    model.periods, rule=storage_charge_power_rule1)
model.storage_discharge_power_cstr1 = Constraint(
    model.periods, rule=storage_discharge_power_rule1)
model.storage_charge_power_cstr2 = Constraint(
    model.periods, rule=storage_charge_power_rule2)
model.storage_discharge_power_cstr2 = Constraint(
    model.periods, rule=storage_discharge_power_rule2)

model.PV_generation_cstr1 = Constraint(model.periods, rule=PV_generation_rule1)
model.PV_generation_cstr2 = Constraint(model.periods, rule=PV_generation_rule2)

model.import_limit_cstr = Constraint(model.periods, rule=import_limit_rule)
model.export_limit_cstr = Constraint(model.periods, rule=export_limit_rule)


model.genset_generation_cstr = Constraint(
    model.periods, rule=genset_generation_rule)


# Create objective
def total_cost(m):
    delta_t = RESOLUTION_IN_MINUTES / 60.
    opex = sum(
        m.steer_genset_sp[p] * delta_t * FUEL_PRICE_COEFF / 1000. for p in model.periods) * 365 / N_DAYS * INVESTMENT_HORIZON
    opex += sum(m.imp_grid[p] * delta_t * GRID_IMPORT_PRICE /
                1000. for p in model.periods) * 365 / N_DAYS * INVESTMENT_HORIZON
    opex -= sum(m.exp_grid[p] *delta_t * GRID_EXPORT_PRICE /
                1000. for p in model.periods) * 365 / N_DAYS * INVESTMENT_HORIZON
    return opex

model.obj = Objective(rule=total_cost, sense=pyo.minimize)

# Solve the model
opt = utils.configure_solver(solver_name="cplex") # or ipopt or cbc
if EXPORT_MODEL:
    print("Exporting model...")
    utils.export_model(model)
print("Solving model...")
results = opt.solve(model, tee=False, keepfiles=False)

# Check is the problem is feasible
status = results.solver.status
termination_condition = results.solver.termination_condition

print("\nSolver status:", status, termination_condition)
utils.plot_and_print(model,data)
