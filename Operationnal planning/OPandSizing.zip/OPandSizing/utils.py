# This file contains utility functions. You mostly do not want to touch this file.

from datetime import timedelta, datetime
from pyomo.opt import SolverFactory
from pyomo.opt import ProblemFormat
import pandas as pd
from parameters import RESOLUTION_IN_MINUTES,INVERTER_UNIT_CAPACITY,STORAGE_UNIT_CAPACITY, ANNUAL_CONSUMPTION
import matplotlib.pyplot as plt 

from pyomo.core.kernel import value
class SizingData():

    def __init__(self, start_date=datetime(2020, 3, 1, 0, 0, 0)):
        """

        :param start_date: The start date you want to consider for sizing.
        """
        def date_parse(x): return datetime.strptime(
            x, '%Y-%m-%d %H:%M:%S')  # Parsing function

        # Columns are named "C" (consumption) and "P" (production)
        data_df = pd.read_csv("sizing_new.CSV", index_col="DateTime",
                              parse_dates=True, date_parser=date_parse)

        self.data_df = data_df
        
    def consumption(self, p):
        """

        :param p: period index, starts at 1
        :return: instantaneous power consumption [W]
        """
        datetime = self.data_df.index[0] + \
            timedelta(hours=(p-1) * RESOLUTION_IN_MINUTES / 60)
        # DEBUG print(datetime.strftime('%Y-%m-%d %H:%M:%S'))
        return self.data_df.loc[datetime]["load"] * ANNUAL_CONSUMPTION * 60 / RESOLUTION_IN_MINUTES

    def PV_generation(self, p):
        """

        :param p: period index, starts at 1
        :return: PV generation per unit of capacity [W]
        """
        datetime = self.data_df.index[0] + \
            timedelta(hours=(p-1) * RESOLUTION_IN_MINUTES / 60)
        return self.data_df.loc[datetime]["PV"].clip(min=0)


def configure_solver(model, solver_name="gurobi"):
    """
    :param model: the model to be solved
    :param solver_name: solver name as a string
    :return: a configured pyomo solver object
    """
    opt = SolverFactory('gurobi_persistent')
    opt.set_instance(model)
    return opt


def export_model(model):
    """
    :param model: Pyomo optimization model
    :return: Nothing, dumps lp file sizing_opt.lp
    """
    model.write(filename="sizing_opt.lp",
                format=ProblemFormat.cpxlp,
                io_options={"symbolic_solver_labels": True})
    
def plot_and_print(model, data, sizing=False):
    delta_t=RESOLUTION_IN_MINUTES/60.
    conso = [-data.consumption(p) for p in model.periods]
    PV = [model.gen_PV_sp[p].value for p in model.periods]
    steer = [model.steer_genset_sp[p].value for p in model.periods]
    imp = [model.imp_grid[p].value for p in model.periods]
    exp = [-model.exp_grid[p].value for p in model.periods]
    charge = [-model.charge_storage_sp[p].value for p in model.periods]
    discharge = [model.discharge_storage_sp[p].value for p in model.periods]
        
    fig, ax = plt.subplots(1, 1, dpi=720)
    ax.stackplot(model.periods, conso,exp, charge, labels=['Consumption','Grid export', 'Battery charge'])
    #plt.plot(PV_max, label='PV max')
    ax.stackplot(model.periods,PV,steer,imp,discharge, labels=['PV','Genset','Grid import', 'Battery discharge'])
    
    ax.legend()
    
    if sizing:
        print("\nSizing decisions:")
        print("  - Storage capacity: %d kWh"  % (
            model.storage_energy_capacity_units.value * STORAGE_UNIT_CAPACITY/1e3))
        print("  - Storage inverter capacity: %d kVA"  % (
            model.storage_inverter_capacity_units.value * INVERTER_UNIT_CAPACITY/1e3))
        print("  - PV capacity: %d kWp"  % (model.PV_capacity.value/1e3))
        print("  - PV inverter capacity: %d kVA"  % (
            model.PV_inverter_capacity_units.value * INVERTER_UNIT_CAPACITY/1e3))
        print("  - Grid connection capacity: %d A"  % (
            sum(o * model.grid_capacity[o].value for o in model.grid_capacity_options)))
        print("  - Genset capacity: %d kVA"  % (
            sum(o * model.genset_capacity[o].value for o in model.genset_capacity_options)/1e3))
    
    print("\nTotal negative energy (consumption):")
    print("  - Base consumption: %d kWh" % (sum(conso)*delta_t/1e3))
    print("  - Grid export: %d kWh" % (sum(exp)*delta_t/1e3))
    print("  - Battery charge: %d kWh" % (sum(charge)*delta_t/1e3))
    
    
    print("\nTotal positive energy (production):")
    print("  - PV production: %d kWh" % (sum(PV)*delta_t/1e3))
    print("  - Genset production: %d kWh" % (sum(steer)*delta_t/1e3))
    print("  - Grid import: %d kWh" % (sum(imp)*delta_t/1e3))
    print("  - Battery discharge: %d kWh"% (sum(discharge)*delta_t/1e3))
    
    print("\nCost for the considered period [€]: %d" %(value(model.obj)))
    
    return steer, PV, imp, exp
