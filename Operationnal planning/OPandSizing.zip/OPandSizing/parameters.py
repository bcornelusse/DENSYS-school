# This file contains parameters you may want to play with.

from datetime import datetime
# Parameters

# SOLVER_CONFIGURATION
EXPORT_MODEL = False

# ANNUAL PARAMETERS
ANNUAL_CONSUMPTION = 0   # [Wh] # TODO: add your annual consumption.

# Time 
# Start date of the sizing run. No error handling if out of the data range.
START_DATE = datetime(2021, 1, 1, 0, 0, 0)           # TODO: You can change that, but there is only data for 2021                                                   
N_DAYS = 30                                          # Number of days to simulate, from start_date [day] #TODO: Change to 365 to finalize
RESOLUTION_IN_MINUTES = 15                           # Time step duration [min]
N_PERIODS = N_DAYS * 24 * 60 / RESOLUTION_IN_MINUTES # Number of operation time steps
INVESTMENT_HORIZON = 20                              # [Years] Investment horizon

# Storage device

STORAGE_UNIT_PRICE =    320   # [EUR]
STORAGE_MAX_P_RATE =    1.8   # [W/Wh]
INITIAL_SOC =           0     # [Wh] 
CHARGE_EFFICIENCY =     0.95  # [/]
DISCHARGE_EFFICIENCY =  0.95  # [/]

# Inverter capacity
INVERTER_UNIT_CAPACITY = 1000   # [VA]
INVERTER_UNIT_PRICE =    0.15   # [EUR/VA]
PROSUMER_TARIF =         0.070  # [EUR/VA.year]

# PV
PV_CAPACITY_PRICE = 0.5  # [EUR/Wp]
PV_MAX_CAPACITY =   0    # TODO: Depending on your roofsize, you can relax afterwards and see effects


#GRID cost
GRID_VOLTAGE =      230           # [V]
GRID_IMPORT_PRICE = 0.4           # [EUR/kWh]
GRID_EXPORT_PRICE = 0.04          # [EUR/kWh]
GRID_CAPACITY_PRICE = 100         # [EUR/kW.year] 
                                                
# Genset
GENSET_CAPACITY_PRICE =  100      # [EUR/kVA.year] 
FUEL_PRICE_COEFF = 2/(10.74*0.4)  # [EUR/kWh] cost/(energy_density*efficiency)


############### 
#CO2
# Variable emission
FUEL_CO2 = 0.300     # g/Wh
# You can add a CO2 emission for grid import and test the model in non islanded mode

# Fixed emission
PV_CO2 =       1.8e3 # g/Wp
INVERTER_CO2 = 60    # g/VA
STORAGE_CO2 =  150   # g/Wh
GENSET_CO2 =   11e3  # g/KVA installed

