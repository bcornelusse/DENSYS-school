import matplotlib.pyplot as plt
#import pandas as pd
#import numpy as np
from param import *

def check_res(res):
    eps = 1e-4                  # error tolerance
    for t in range(time_steps):
        # TODO: Check if everything time_step is correct for all know constraints.
        # Example, power balance:
        if abs(res.P_pv[t] + res.P_gen[t] - res.P_bss[t] - res.P_ev[t] - res.P_load[t] - res.P_hp[t]) >= eps:
            print(f'Error: power balance offset ({res.P_pv[t] + res.P_gen[t] - res.P_bss[t] - res.P_ev[t] - res.P_load[t] - res.P_hp[t]}), at time step {t} \
                  [P_pv, P_gen, P_bss, P_ev, P_load, P_hp]: [{res.P_pv[t]}, {res.P_gen[t]}, {res.P_bss[t]}, {res.P_ev[t]}, {res.P_load[t]}, {res.P_hp[t]}]')
        
    return

def print_res(res):
    # TODO: Print relevant information
    return


def plot_res(res):
    # TODO: Make one or multiple plots with the results throughout the day
    return