from param import delta_t#, time_steps, total_hours
from param import P_nom_pv, P_max_gen, P_min_gen, C_bss, SOC_min_bss, SOC_max_bss, eff_bss, P_nom_bss
from param import C_ev, eff_ev, SOC_min_ev, SOC_max_ev, P_nom_ev, SOC_target_ev, P_max_hp, COP_hp, C_hp, delta_T_max

from pyomo.environ import ConcreteModel, Param, Var, Objective, Constraint, value, NonNegativeReals, Binary, minimize, SolverFactory, SolverStatus
import run as run

Scenario = "S1" # Change to S2, S3, S4 to test the different scenarios

# =============================================================================
# Penalty costs
# =============================================================================
PI_gen = 0.5    # €/kWh
PI_curt = 0     # TODO: Change
# TODO: Add other penalty if needed

def create_model():
    # Create a concrete model
    model = ConcreteModel()
    
    # Mutable parameters that will be updated at each time step
    model.SOC_ev = Param(mutable=True)                         # Current electric vehicle state of charge [0, 1]
    model.SOC_bss = Param(mutable=True)                     # Current battery state of charge [0, 1]
    model.P_load = Param(mutable=True)                      # Current load [kW] 
    model.P_pv_max = Param(mutable=True)                    # Current max available PV power [kW]
    model.EV_connected = Param(mutable=True, within=Binary) # Depends on wether the electric vehicle is connected or not {0,1}
    model.EV_time_remaining = Param(mutable=True)           # Time remaining before the EV is leaving [h]
    model.Pgen_prev = Param(mutable=True, initialize=0)     # Power output of the generator at the previous time step [kW]
    model.P_loss = Param(mutable=True)                      # Thermal power lost outside the house [kW]
    model.T_set = Param(mutable=True)                       # Temperature setpoint [°C]
    model.T_hp = Param(mutable=True)                        # Current temperature inside the house [°C]

    # TODO: You may have to add mutable parameters

    # Variables
    model.P_pv = Var(within=NonNegativeReals)               # PV power output 
    model.P_gen = Var(within=NonNegativeReals)              # Generator power output 
    model.P_charge_bss = Var(within=NonNegativeReals)       # Battery charging power 
    model.P_discharge_bss = Var(within=NonNegativeReals)    # Battery discharging power 
    model.P_charge_ev = Var(within=NonNegativeReals)        # EV charging power 
    model.P_discharge_ev = Var(within=NonNegativeReals)     # EV discharging power 
    model.P_hp = Var(within=NonNegativeReals)               # HP charging power

    # Binary variables for mode control
    model.gen_status = Var(within=Binary, initialize=0)     # Indicates whether generator is on 
    
    # Added variables
    #TODO: You may have to add additional variables
        
    # Define the objective function ----------------------------------------------------------------------------
    model.objective = Objective(sense=minimize,
    expr=0) # TODO: Design objective
    
    #Constraints ---------------------------------------------------------------------------------------------------------------------------
    # Power balance constraint:
    model.P_bal_cstr = Constraint(expr= model.P_pv + model.P_gen + model.P_discharge_bss + model.P_discharge_ev 
                                  == model.P_load + model.P_hp +  model.P_charge_bss + model.P_charge_ev)
    
    # PV constraints:
    # TODO: Add constraints 

    # Battery constraints:
    # TODO: Add constraints 

    # EV constraints:
    # TODO: Add constraints 

    # HP constraints
    # TODO: Add constraints 

    # Generator minimum and maximum power constraints: 
    # TODO: Add constraints 
    
    return model

# =============================================================================
# Function to run the simulation, update and solve the model
# These functions will be called at each time step
# You should not need to modify these functions
# Your final should still be able to run with these functions unchanged
# You can still modify the functions if you want for testing purposes
# =============================================================================

def solve_model(model):
    solver = SolverFactory('gurobi')
    results = solver.solve(model)
    if results.solver.status not in [SolverStatus.ok, SolverStatus.warning]:
        print("Solver status:", results.solver.status)

def update_model(model, SOC_bss, SOC_ev, P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev, P_loss, T_set, T_hp):
    model.SOC_ev = SOC_ev
    model.SOC_bss = SOC_bss
    model.P_load = P_load
    model.P_pv_max = P_pv_max
    model.EV_connected = EV_connected
    model.EV_time_remaining = EV_remaining_time
    model.Pgen_prev = P_gen_prev
    model.P_loss = P_loss
    model.T_set = T_set
    model.T_hp = T_hp

    # TODO: If you added mutable parameters you should update them here

    return model

def control_decision(P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev, SOC_bss, SOC_ev, P_loss, T_set, T_hp, model):
    # Control decision function same as previously, except you are now using the pyomo "model" object.
    # You do not have to change this function but you can, however do not change its inputs and outputs


    model = update_model(model, SOC_bss, SOC_ev, P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev, P_loss, T_set, T_hp)

    solve_model(model)

    try:
        P_pv = model.P_pv.value
        P_gen = model.P_gen.value
        P_bss = model.P_charge_bss.value - model.P_discharge_bss.value
        P_ev = model.P_charge_ev.value - model.P_discharge_ev.value
        P_hp = model.P_hp.value
    except:
        print("WARNING: Problem with solution encountered")
        P_pv = P_gen = P_bss = P_ev = P_hp = 0
    return P_pv, P_gen, P_bss, P_ev, P_hp

model = create_model()
run.run_sim(control_decision, Scenario, model)
