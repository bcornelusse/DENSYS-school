from param import delta_t, time_steps
from param import P_nom_pv, P_max_gen, P_min_gen, C_bss, SOC_min_bss, SOC_max_bss, eff_bss, P_nom_bss
from param import C_ev, eff_ev, SOC_min_ev, SOC_max_ev, P_nom_ev, SOC_target_ev, P_max_hp
import run

Scenario = 'S1' # Change to S1, S2, S3 or S4


#===============================================================================================================#
    # Control decision function
    # This function is used to determine the power setpoints for the different components of the system
    # It is called at each time step to determine the power setpoints for the next time step
    
    # The function should return the following values:
    # P_pv: Power output of the PV system [kW]
    # P_gen: Power output of the generator [kW]
    # P_bss: Power output of the battery [kW]. A positive value means charging and negative is discharging.
    # P_ev: Power output of the EV [kW]. A positive value means charging and negative is discharging.
    # P_hp: Power output of the HP [kW]. This value is the electric power and should be multiplied by COP_hp for the thermal input.

    #####
    # These values are used to update the state of the system in the simulator

    # The function takes the following inputs:
    # t: Current time step [-]
    # P_load: Demand at the current time step [kW]
    # P_pv_max: Maximum available power from the PV system [kW]
    # EV_connected: Maximum power that can be drawn from the EV {0;1}
    # EV_remaining_time: Time remaining before the EV leaves [h]
    # P_gen_prev: Power output of the generator at the previous time step [kW]
    # SOC_bss: Current battery state of charge [0, 1]
    # SOC_EV: Current EV state of charge [0, 1]
    # P_loss: Current thermal power losses in the house [kW]
    # T_set: Current home temperature setpoint [°C]
    # T_hp: Current inside temperature [°C]
    # model=None: No need for an optimization model in this first part. Do not use this input.

#===============================================================================================================#
def control_decision(P_load, P_pv_max, EV_connected, EV_remaining_time, P_gen_prev, SOC_bss, SOC_ev, P_loss, T_set, T_hp, model=None):
    # TODO: Implement a rule-based controller here

    P_pv = 0
    P_gen = 0
    P_bss = 0
    P_ev = 0
    P_hp = 0
    
    return P_pv, P_gen, P_bss, P_ev, P_hp

results = run.run_sim(control_decision, Scenario)
